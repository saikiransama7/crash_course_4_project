package com.example.loginservice.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.loginservice.model.User;
import com.example.loginservice.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@RequestMapping("/")
@CrossOrigin
public class UserController {
	
	@Autowired
	private UserService service;

	@PostMapping("/add")
	public ResponseEntity<?> adduser(@RequestBody User user){
		ResponseEntity<?> entity = new ResponseEntity<String>("Error in creating user....",HttpStatus.BAD_REQUEST);
		boolean b = service.addUser(user);
		if(b) {
			 entity = new ResponseEntity<String>("User Added Successfully....", HttpStatus.CREATED);
			
		}
		return entity;
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> userLogin(@RequestBody User user){
		ResponseEntity<?> entity = new ResponseEntity<String>("false sorry",HttpStatus.BAD_REQUEST);
		boolean b = service.validateUser(user);
		if(b) {
			Map<String, String> map = getToken(user.getEmailId());
			entity = new ResponseEntity<Map<String, String>>(map,HttpStatus.OK);
		}
		return entity;
	}

	private Map<String,String> getToken(String emailId) {
		long tim = System.currentTimeMillis()+1000*60*10;
		
		String jwtToken = Jwts.builder()
				.setIssuedAt(new Date())
				.setSubject(emailId)
				.signWith(SignatureAlgorithm.HS256, "saikiran")
				.compact();
		Map<String, String> map = new HashMap<>();
		map.put("token", jwtToken);
		map.put("message", "User successfully logged in");
		return map;
		}
	
}
