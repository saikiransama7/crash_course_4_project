package com.example.loginservice.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class User {
	@Id
	private String emailId;
	private String firstName;
	private String lastName;
	private String userName;
	private String contactNumber;
	private String password;
	

}
