package com.example.loginservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.loginservice.model.User;
import com.example.loginservice.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository repo;
	
	
	public boolean addUser(User user) {
		boolean b = false;
		Optional<User> op = repo.findById(user.getEmailId());
		if(op.isEmpty()) {
			repo.save(user);
			b = true;
		}
		return b;
	}
	
	public boolean validateUser(User user) {
		boolean b = false;
		Optional<User> op = repo.findById(user.getEmailId());
		if(op.isPresent()) {
			User userobj = op.get();
			if(userobj.getPassword().equals(user.getPassword())) {
				b = true;
			}
		}
		return b;
	}

}
