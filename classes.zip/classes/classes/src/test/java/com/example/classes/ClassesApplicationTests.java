package com.example.classes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassesApplicationTests {

	@Test
	void contextLoads() {
	}

}
