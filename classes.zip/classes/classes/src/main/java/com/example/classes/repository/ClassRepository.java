package com.example.classes.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.classes.model.ClassDetails;

@Repository
public interface ClassRepository extends MongoRepository<ClassDetails, Integer>{

}
