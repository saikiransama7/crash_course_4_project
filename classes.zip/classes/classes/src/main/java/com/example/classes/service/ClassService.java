package com.example.classes.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.classes.model.ClassDetails;
import com.example.classes.repository.ClassRepository;

@Service
public class ClassService {

	@Autowired
	private ClassRepository repo;
	
	public boolean addStudent(ClassDetails student) {
		boolean b = false;
		Optional<ClassDetails> op = repo.findById(student.getRollNo());
		if(op.isEmpty()) {
			repo.save(student);
			b = true;
		}
		return b;
	}
	
	
	public List<ClassDetails> getAllStudents(){
		List<ClassDetails> list = repo.findAll();
		return list;
	}
	
	public boolean deleteStudent(ClassDetails student) {
		boolean b = false;
		Optional<ClassDetails> op = repo.findById(student.getRollNo());
		if(op.isPresent()) {
			repo.delete(student);
			b = true;
		}
		return b;
	}
	public boolean updateStudent(ClassDetails student) {
		boolean b = false;
		Optional<ClassDetails> op = repo.findById(student.getRollNo());
		if(op.isPresent()) {
			ClassDetails clas = op.get();
			clas.setClassId(student.getClassId());
			clas.setStudentName(student.getStudentName());
			clas.setAttendance(student.getAttendance());
			repo.save(clas);
			b = true;
		}
		return b;
	}
	
	public ClassDetails getUserByRollNo(int rollNo) {
		Optional<ClassDetails> opt = repo.findById(rollNo);
		ClassDetails userObj = opt.isPresent() ? opt.get() : null;
		return userObj;
	}
}

