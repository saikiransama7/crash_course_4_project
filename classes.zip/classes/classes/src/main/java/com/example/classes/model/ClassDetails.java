package com.example.classes.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Document
public class ClassDetails {
	
	@Id
	private int rollNo;
	private int classId;
	private String studentName;
	private int attendance;

}
