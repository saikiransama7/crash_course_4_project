package com.example.classes.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.classes.model.ClassDetails;
import com.example.classes.service.ClassService;

@RestController
@RequestMapping("/")
@CrossOrigin
public class ClassController {

	@Autowired
	private ClassService service;
	
	@PostMapping("/add")
	public ResponseEntity<?> addUser(@RequestBody ClassDetails student){
		ResponseEntity<?> entity = new ResponseEntity<String>("Failed...",HttpStatus.BAD_REQUEST);
		boolean b = service.addStudent(student);
		if(b) {
			entity = new ResponseEntity<String>("Student added...",HttpStatus.OK);
		}
		return entity;
	}
	
	
	@GetMapping("/students")
	public ResponseEntity<?> getAllStudent(){
		List<ClassDetails> list = service.getAllStudents();
		ResponseEntity<List<ClassDetails>>  entity = new ResponseEntity<List<ClassDetails>>(list,HttpStatus.OK);
		return entity;
	}
	
	@PostMapping("/update")
	public ResponseEntity<?> updateStudentDetails(@RequestBody ClassDetails student){
		ResponseEntity<?> entity = new ResponseEntity<String>("Failed...",HttpStatus.BAD_REQUEST);
		boolean b = service.updateStudent(student);
		if(b) {
			entity = new ResponseEntity<String>("Student details updated...",HttpStatus.OK);
		}
		return entity;
	}
	
	@DeleteMapping("/delete/{rollNo}")
	public ResponseEntity<?> deleteStudent(@PathVariable int rollNo){
		ResponseEntity<?> entity = new ResponseEntity<String>("Failed...",HttpStatus.BAD_REQUEST);
		ClassDetails cls = service.getUserByRollNo(rollNo);
		if(cls!=null) {
			service.deleteStudent(cls);
			entity = new ResponseEntity<String>("Student deleted....",HttpStatus.OK);
		}
		return entity;
	}
	
	@GetMapping("/get/{rollNo}")
	public ResponseEntity<?> getStudent(@PathVariable int rollNo){
		ResponseEntity<?> entity = new ResponseEntity<String>("Failed...",HttpStatus.BAD_REQUEST);
		ClassDetails cls = service.getUserByRollNo(rollNo);
		if(cls!=null) {
			entity = new ResponseEntity<ClassDetails>(cls,HttpStatus.OK);
		}
		return entity;
	}
	
}
