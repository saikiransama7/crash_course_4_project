import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/auth.guard';
import { AddstudentComponent } from './components/addstudent/addstudent.component';
import { ClassesComponent } from './components/classes/classes.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { UpdatestudentComponent } from './components/updatestudent/updatestudent.component';

const routes: Routes = [
  {path:'login',component: LoginComponent},
  {path:'',component: HomeComponent},
  {path:'register',component: RegisterComponent},
  {path:'add',component: AddstudentComponent},
  {path:'update/:rollNo',component: UpdatestudentComponent},
  {path:'student',component: ClassesComponent, canActivate:[AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
