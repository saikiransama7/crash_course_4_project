import { Component, OnInit } from '@angular/core';
import { CrudService } from 'src/services/crud.service';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {
  
  constructor(private service:CrudService) { }
  student={
    rollNo:'',
    classId:'',
    studentName:'',
    attendance:''
  }

  getDetails(){
    if(this.student.rollNo!='' && this.student.classId!='' && this.student.studentName!='' && this.student.attendance!='' && this.student.rollNo!=null && this.student.classId!=null && this.student.studentName!=null && this.student.attendance!=null){
      this.service.addStudent(this.student).subscribe(result=>{
        alert("Student added successfully"),
        window.location.href=("/student")
      },
      error=>{
        alert("Student not added/change the RollNo")
      }
      )
    }else{
      alert("All fields should be field")
    }


  }
  

  ngOnInit(): void {
  }

}
