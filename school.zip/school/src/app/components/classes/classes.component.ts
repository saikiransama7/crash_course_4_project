import { Component, OnInit } from '@angular/core';
import { CrudService } from 'src/services/crud.service';

@Component({
  selector: 'app-classes',
  templateUrl: './classes.component.html',
  styleUrls: ['./classes.component.css']
})
export class ClassesComponent implements OnInit {
  students:any;
  user :any;

  constructor(private crudservice:CrudService) { 
    this.crudservice.getAllStudents().subscribe(results=>{
      this.students=results
      console.log("success")
    })
  }

  deleteStudent(rollNo:any){
    this.crudservice.deleteStud(rollNo).subscribe(data=>{
      console.log("User deleted")
      alert("User deleted")
      location.reload();
    },
    error=>{
      console.log("User deletion failed")
      alert("User deletion failed")

    })

  }
  
  ngOnInit(): void {
  }

}


