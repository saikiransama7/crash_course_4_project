import { Component, OnInit } from '@angular/core';
import { LoginserviceService } from 'src/services/loginservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userDetails={
    emailId:'',
    password:''
  }
  constructor(private loginService:LoginserviceService) { }

  ngOnInit(): void {
  }

  getValue(){
    // this.userDetails.emailId =emailId
    // console.log("form is submitted");
    console.log(this.userDetails);
      if((this.userDetails.emailId!='' && this.userDetails.password!='')&&(this.userDetails.emailId!=null&&this.userDetails.password!=null)){
         console.log("login succesfull");
          this.loginService.sendDetails(this.userDetails).subscribe(
            (responce:any)=>{
              console.log(responce.token);
              console.log("success");
              this.loginService.loginUser(responce.token)
              window.location.href=("student")
            },
            error=>{
              console.log(error);
              console.log("failed");
              alert("EmailId or Password is incorrect");
            }
          )
      }else{
        console.log("feilds are empty");
        alert("feilds are empty")
      }
    }

}
