import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CrudService } from 'src/services/crud.service';
import { Student } from 'src/app/student';

@Component({
  selector: 'app-updatestudent',
  templateUrl: './updatestudent.component.html',
  styleUrls: ['./updatestudent.component.css']
})
export class UpdatestudentComponent implements OnInit {

  roll : any;
  student : Student = new Student()
  
  constructor(private service:CrudService, private router:ActivatedRoute) {}
  
  
  ngOnInit(): void {
    
    this.roll = this.router.snapshot.params['rollNo'];
    this.service.getStudent(this.roll).subscribe((data:any)=>{
      this.student = data
    })
    
  }
  
  updateDetails(){
    if(this.student.rollNo!='' && this.student.classId!='' && this.student.studentName!='' && this.student.attendance!='' && this.student.rollNo!=null && this.student.classId!=null && this.student.studentName!=null && this.student.attendance!=null){
      this.service.updateStud(this.student).subscribe(data=>{
        alert("User updated")
        window.location.href=("/student")
      },
      error=>{
        alert("User not Updated")
      }
      )
    }else{
      alert("Fill the data in the blank space")
    }
  }
}
