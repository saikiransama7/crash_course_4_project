import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginserviceService } from 'src/services/loginservice.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  constructor(private loginservice:LoginserviceService,private router:Router) { }
  
  
  
  getDetails={
    emailId:'',
    firstName:'',
    lastName:'',
	 userName:'',
	 contactNumber:'',
	 password:'',
   cpassword:''
  }
  
  getValues(){
    if(this.getDetails.firstName.charCodeAt(0)!==32 && this.getDetails.lastName.charCodeAt(0)!==32 && this.getDetails.emailId.charCodeAt(0)!==32 && this.getDetails.contactNumber.charCodeAt(0)!==32 && this.getDetails.password.charCodeAt(0)!==32 && this.getDetails.userName.charCodeAt(0)!==32){
      
        if(this.getDetails.cpassword==this.getDetails.password){
          console.log("form is submitted")
          this.loginservice.adduser(this.getDetails).subscribe( data=> {
              console.log("user added successfully")
              alert("user added successfully")
              this.router.navigate(['/login']);
            },
            error=>{
              console.log(error)
              alert("User already exist")
            }
          )
        }else{
          alert("Password and conform passward should be same")
        }
    }else{
      alert("space is not allowed")
    }
  }

  ngOnInit(): void {
  }

}
