import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoginserviceService } from 'src/services/loginservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'school';
  public loggedIn= false;
  userId :any;

  constructor(private loginservice:LoginserviceService, private router:ActivatedRoute){

  }

  ngOnInit(): void {
    // throw new Error('Method not implemented.');
    this.loggedIn=this.loginservice.isLoggedIn()
    this.userId = this.router.snapshot.params['userName']
    console.log(this.userId)
  }

  logoutUser(){
    this.loginservice.logout()
    location.reload()
  }
}
