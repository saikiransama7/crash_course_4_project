export class Student {
    rollNo!: '';
    classId!:'';
    studentName!:'';
    attendance!:'';
  }