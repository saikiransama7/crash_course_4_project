import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {
  url = "http://localhost:8083/login"
  register = "http://localhost:8083/add"

  constructor(private http:HttpClient) { }

  sendDetails(userDetails:any){
    return this.http.post(`${this.url}`,userDetails)
  }
  adduser(userDetails:any){
    return this.http.post(`${this.register}`,userDetails,{responseType :'text' as 'json'})
  }
  
  loginUser(token:any)
  {
    // if(token!=false){
      localStorage.setItem("token",token);
      return true;
    // }else{
    //   return false;
    // }
  }
  
  isLoggedIn(){
    let token = localStorage.getItem("token");
    if(token==undefined || token ==='' || token == null){
      return false;
    }else{
      return true;
    }
  }
  
  logout(){
    localStorage.removeItem("token")
    return true;
  }

  getToken(){
    return localStorage.getItem("token");
  }
}
