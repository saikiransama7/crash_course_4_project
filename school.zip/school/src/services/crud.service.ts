import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CrudService {

  add = "http://localhost:8082/add"
  users = "http://localhost:8082/students"
  update ="http://localhost:8082/update"

  constructor(private http:HttpClient) { }

  addStudent(student:any){
    return this.http.post(`${this.add}`,student,{responseType:'text' as 'json'})
  }

  getAllStudents(){
    return this.http.get(`${this.users}`)
  }
  deleteStud(rollNo:any){
    return this.http.delete("http://localhost:8082/delete/"+rollNo, {responseType:'text' as 'json'})
  }
  updateStud(userDetails:any){
    return this.http.post(`${this.update}`,userDetails,{responseType:'text' as 'json'})
  }
  getStudent(rollNo:number){
    return this.http.get("http://localhost:8082/get/"+rollNo)
  }
}